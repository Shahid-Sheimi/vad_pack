# my_vad/__init__.py

from .vad import apply_vad
