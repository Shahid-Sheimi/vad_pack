# My VAD

`my_vad` is a Python package for applying voice activity detection (VAD) using the Silero VAD model.

## Installation

You can install the package using pip:

```bash
pip install my_vad
